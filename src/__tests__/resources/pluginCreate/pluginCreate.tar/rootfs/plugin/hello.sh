#!/bin/sh
echo "Hello, World!";
sleep infinity;
